echo "Configure the scripts"

aclocal
autoconf
autoheader
automake -c -a
