#ifndef BASIC_H
#define BASIC_H


void Basic( unsigned char * BufFile, char * Listing, bool IsBasic, bool CrLf );


#endif
