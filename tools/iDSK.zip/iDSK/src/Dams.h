#ifndef DAMS_H
#define DAMS_H


void Dams( unsigned char * BufFile, int TailleFic, char * Listing );


#endif
