#ifndef __VIEWFILE_H__
#define __VIEWFILE_H__




string ViewDams();
string ViewLine();
string ViewDesass();
string ViewBasic();
	

#endif
