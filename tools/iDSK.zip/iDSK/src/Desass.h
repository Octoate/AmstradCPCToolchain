#ifndef DESASS_H
#define DESASS_H


void Desass( unsigned char * Prg, char * Desass, int Longueur );


#endif
